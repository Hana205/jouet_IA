package com.annalab.jouetlangues

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

sealed class OrchestratorState {
    object Idle : OrchestratorState()
    object Listening : OrchestratorState()
    object Recognizing : OrchestratorState()
    data class Recognized(val frenchText: String) : OrchestratorState()
    object Translating : OrchestratorState()
    data class Translated(val frenchText: String, val translatedText: String) : OrchestratorState()
    object Synthesizing : OrchestratorState()
    data class Done(val frenchText: String, val translatedText: String, val audio: ByteArray) : OrchestratorState()
    data class Error(val step: String, val message: String) : OrchestratorState()
}

/**
 * Enchaîne : audio brut ESP32 -> texte FR (ASR) -> texte cible (Ark) -> audio cible (TTS).
 * Expose un StateFlow pour piloter l'UI (MainActivity) sans callbacks imbriqués.
 */
class TranslationOrchestrator(
    private val asrApi: AsrApi = AsrApi(),
    private val translateApi: TranslateApi = TranslateApi(),
    private val ttsApi: TtsApi = TtsApi()
) {
    private val _state = MutableStateFlow<OrchestratorState>(OrchestratorState.Idle)
    val state: StateFlow<OrchestratorState> = _state

    suspend fun process(pcmAudio: ByteArray, target: VolcengineConfig.TargetLanguage) {
        _state.value = OrchestratorState.Recognizing

        val asrResult = asrApi.recognizeFrench(pcmAudio)
        val frenchText = asrResult.getOrElse {
            _state.value = OrchestratorState.Error("ASR", it.message ?: "erreur inconnue")
            return
        }
        _state.value = OrchestratorState.Recognized(frenchText)

        _state.value = OrchestratorState.Translating
        val translateResult = translateApi.translate(frenchText, target)
        val translatedText = translateResult.getOrElse {
            _state.value = OrchestratorState.Error("Traduction", it.message ?: "erreur inconnue")
            return
        }
        _state.value = OrchestratorState.Translated(frenchText, translatedText)

        _state.value = OrchestratorState.Synthesizing
        val ttsResult = ttsApi.synthesize(translatedText, target)
        val audio = ttsResult.getOrElse {
            _state.value = OrchestratorState.Error("TTS", it.message ?: "erreur inconnue")
            return
        }

        _state.value = OrchestratorState.Done(frenchText, translatedText, audio)
    }

    fun reset() {
        _state.value = OrchestratorState.Idle
    }
}
