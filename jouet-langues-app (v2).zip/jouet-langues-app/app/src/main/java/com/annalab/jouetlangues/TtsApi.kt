package com.annalab.jouetlangues

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Synthèse vocale (texte cible -> audio) via 豆包语音 TTS.
 * Retourne du MP3 par défaut (plus simple à décoder/jouer côté Android avec MediaPlayer
 * qu'un flux PCM brut).
 */
class TtsApi {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    suspend fun synthesize(
        text: String,
        target: VolcengineConfig.TargetLanguage
    ): Result<ByteArray> = withContext(Dispatchers.IO) {
        try {
            val body = JSONObject().apply {
                put("app", JSONObject().apply {
                    put("appid", VolcengineConfig.voiceAppId)
                    put("cluster", "volcano_tts")
                })
                put("user", JSONObject().apply { put("uid", "jouet-langues") })
                put("audio", JSONObject().apply {
                    put("voice_type", target.ttsVoice)
                    put("encoding", "mp3")
                    put("speed_ratio", 0.9) // un peu plus lent, adapté aux enfants
                })
                put("request", JSONObject().apply {
                    put("reqid", System.currentTimeMillis().toString())
                    put("text", text)
                    put("operation", "query")
                })
            }

            val request = Request.Builder()
                .url(VolcengineConfig.TTS_URL)
                .addHeader("Authorization", "Bearer;${VolcengineConfig.voiceAccessToken}")
                .addHeader("Content-Type", "application/json")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("TTS HTTP ${response.code} : $raw"))
                }
                val json = JSONObject(raw)
                val audioB64 = json.optString("data", "")
                if (audioB64.isBlank()) {
                    Result.failure(Exception("Pas d'audio renvoyé. Brut : $raw"))
                } else {
                    Result.success(Base64.decode(audioB64, Base64.DEFAULT))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
