package com.annalab.jouetlangues

import android.bluetooth.BluetoothDevice
import android.media.MediaPlayer
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

/**
 * UI avec bascule entre 3 modes :
 *  - TRANSLATION : traduction rapide FR -> langue cible (comportement d'origine)
 *  - CONVERSATION : l'enfant parle en français, un tuteur IA répond dans la langue cible
 *  - LESSON : mini-leçons guidées avec quiz à choix multiple
 *
 * Dans tous les modes, la parole de l'enfant arrive via BluetoothSppManager (audio ESP32).
 * En mode LESSON, l'audio de l'enfant n'est pas utilisé pour lancer une leçon (c'est le bouton
 * "Leçon suivante" qui déclenche), mais pourrait servir plus tard pour répondre au quiz à l'oral.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var currentModeLabel: TextView
    private lateinit var nextLessonButton: Button
    private lateinit var quizContainer: LinearLayout
    private lateinit var bluetoothManager: BluetoothSppManager

    private val translationOrchestrator = TranslationOrchestrator()
    private val tutorOrchestrator = TutorOrchestrator()

    private var currentMode = LearningMode.TRANSLATION
    private var targetLanguage = VolcengineConfig.TargetLanguage.CHINESE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        currentModeLabel = findViewById(R.id.currentModeLabel)
        nextLessonButton = findViewById(R.id.nextLessonButton)
        quizContainer = findViewById(R.id.quizContainer)
        val connectButton = findViewById<Button>(R.id.connectButton)

        bluetoothManager = BluetoothSppManager { status ->
            runOnUiThread { statusText.text = status }
        }

        connectButton.setOnClickListener {
            val device = findPairedEsp32()
            if (device == null) {
                statusText.text = "ESP32 non trouvé — vérifie l'appairage Bluetooth"
                return@setOnClickListener
            }
            lifecycleScope.launch {
                val ok = bluetoothManager.connect(device)
                if (ok) {
                    bluetoothManager.startListening { pcmAudio -> onAudioReceived(pcmAudio) }
                }
            }
        }

        findViewById<Button>(R.id.modeTranslationButton).setOnClickListener { switchMode(LearningMode.TRANSLATION) }
        findViewById<Button>(R.id.modeConversationButton).setOnClickListener { switchMode(LearningMode.CONVERSATION) }
        findViewById<Button>(R.id.modeLessonButton).setOnClickListener { switchMode(LearningMode.LESSON) }

        nextLessonButton.setOnClickListener {
            lifecycleScope.launch { tutorOrchestrator.requestNextLesson(targetLanguage) }
        }

        observeTranslationState()
        observeTutorState()
        switchMode(LearningMode.TRANSLATION)
    }

    private fun switchMode(mode: LearningMode) {
        currentMode = mode
        quizContainer.removeAllViews()
        tutorOrchestrator.resetConversation()
        translationOrchestrator.reset()

        currentModeLabel.text = when (mode) {
            LearningMode.TRANSLATION -> "Mode : Traduction"
            LearningMode.CONVERSATION -> "Mode : Conversation avec le tuteur IA"
            LearningMode.LESSON -> "Mode : Leçon guidée"
        }
        nextLessonButton.visibility = if (mode == LearningMode.LESSON) View.VISIBLE else View.GONE
        statusText.text = when (mode) {
            LearningMode.TRANSLATION -> "Appuie sur le bouton du jouet et parle en français"
            LearningMode.CONVERSATION -> "Parle en français au jouet, le tuteur va te répondre"
            LearningMode.LESSON -> "Appuie sur \"Leçon suivante\" pour commencer"
        }
    }

    /** Routeur : dirige l'audio reçu de l'ESP32 vers le bon orchestrateur selon le mode actif. */
    private fun onAudioReceived(pcmAudio: ByteArray) {
        lifecycleScope.launch {
            when (currentMode) {
                LearningMode.TRANSLATION -> translationOrchestrator.process(pcmAudio, targetLanguage)
                LearningMode.CONVERSATION -> tutorOrchestrator.handleChildSpeech(pcmAudio, targetLanguage)
                LearningMode.LESSON -> {
                    // En mode leçon, l'audio du jouet n'est pas utilisé pour l'instant
                    // (le quiz se répond en tapant une option affichée à l'écran).
                }
            }
        }
    }

    private fun observeTranslationState() {
        lifecycleScope.launch {
            translationOrchestrator.state.collect { state ->
                if (currentMode != LearningMode.TRANSLATION) return@collect
                when (state) {
                    is OrchestratorState.Idle -> {}
                    is OrchestratorState.Recognizing -> statusText.text = "🎤 Reconnaissance en cours..."
                    is OrchestratorState.Recognized -> statusText.text = "Compris : \"${state.frenchText}\""
                    is OrchestratorState.Translating -> statusText.text = "🌐 Traduction..."
                    is OrchestratorState.Translated -> statusText.text =
                        "\"${state.frenchText}\" → \"${state.translatedText}\""
                    is OrchestratorState.Synthesizing -> statusText.text = "🔊 Génération de la voix..."
                    is OrchestratorState.Done -> {
                        statusText.text = "\"${state.frenchText}\" → \"${state.translatedText}\""
                        playAudio(state.audio)
                    }
                    is OrchestratorState.Error -> statusText.text = "❌ Erreur (${state.step}) : ${state.message}"
                }
            }
        }
    }

    private fun observeTutorState() {
        lifecycleScope.launch {
            tutorOrchestrator.state.collect { state ->
                if (currentMode == LearningMode.TRANSLATION) return@collect
                when (state) {
                    is TutorState.Idle -> {}
                    is TutorState.Listening -> statusText.text = "🎤 J'écoute..."
                    is TutorState.Thinking -> statusText.text = "🤔 Le tuteur réfléchit..."
                    is TutorState.Synthesizing -> statusText.text = "🔊 Génération de la voix..."
                    is TutorState.ConversationTurn -> {
                        val correctionLine = state.reply.correction?.let { "\n💡 $it" } ?: ""
                        statusText.text = "Toi : \"${state.childText}\"\n" +
                            "Tuteur : \"${state.reply.targetReply}\" (${state.reply.frenchHint})$correctionLine"
                        playAudio(state.audio)
                    }
                    is TutorState.LessonReady -> {
                        showLesson(state.lesson)
                        playAudio(state.audio)
                    }
                    is TutorState.QuizResult -> {
                        statusText.text = if (state.correct) {
                            "✅ Bravo, c'est la bonne réponse !"
                        } else {
                            "❌ Pas tout à fait — la bonne réponse était : ${state.correctAnswer}"
                        }
                    }
                    is TutorState.Error -> statusText.text = "❌ Erreur (${state.step}) : ${state.message}"
                }
            }
        }
    }

    private fun showLesson(lesson: Lesson) {
        statusText.text = "📖 ${lesson.word} (${lesson.translation})\n" +
            "\"${lesson.exampleSentence}\" — ${lesson.exampleTranslation}\n\n${lesson.quizQuestion}"

        quizContainer.removeAllViews()
        lesson.quizOptions.forEachIndexed { index, option ->
            val optionButton = Button(this).apply {
                text = option
                setOnClickListener { tutorOrchestrator.submitQuizAnswer(index) }
            }
            quizContainer.addView(optionButton)
        }
    }

    /** Joue l'audio TTS sur le haut-parleur du téléphone (MVP — voir README pour la V2). */
    private fun playAudio(mp3Bytes: ByteArray) {
        val tempFile = File(cacheDir, "tts_output.mp3")
        FileOutputStream(tempFile).use { it.write(mp3Bytes) }

        MediaPlayer().apply {
            setDataSource(tempFile.absolutePath)
            setOnPreparedListener { start() }
            setOnCompletionListener { release() }
            prepareAsync()
        }
    }

    @Suppress("MissingPermission")
    private fun findPairedEsp32(): BluetoothDevice? {
        val adapter = android.bluetooth.BluetoothAdapter.getDefaultAdapter() ?: return null
        return adapter.bondedDevices.firstOrNull { it.name?.contains("JouetLangues") == true }
    }

    override fun onDestroy() {
        super.onDestroy()
        bluetoothManager.close()
    }
}
