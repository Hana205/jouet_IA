package com.annalab.jouetlangues

/** Les trois modes accessibles depuis l'appli, basculables via l'UI. */
enum class LearningMode {
    TRANSLATION,   // traduction rapide FR -> langue cible (déjà en place)
    CONVERSATION,  // dialogue libre avec un tuteur IA
    LESSON         // mini-leçons guidées (mot du jour + quiz)
}
