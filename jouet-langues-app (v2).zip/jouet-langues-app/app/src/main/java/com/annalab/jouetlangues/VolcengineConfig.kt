package com.annalab.jouetlangues

/**
 * Configuration centrale des accès Volcengine.
 *
 * IMPORTANT : ne jamais committer de vraies clés en dur ici.
 * Injecte-les via BuildConfig (gradle) ou un fichier local non versionné.
 * Exemple dans app/build.gradle.kts :
 *
 *   buildConfigField("String", "ARK_API_KEY", "\"${project.findProperty("ARK_API_KEY")}\"")
 *   buildConfigField("String", "VOICE_APP_ID", "\"${project.findProperty("VOICE_APP_ID")}\"")
 *   buildConfigField("String", "VOICE_ACCESS_TOKEN", "\"${project.findProperty("VOICE_ACCESS_TOKEN")}\"")
 *
 * et dans local.properties (non commité) :
 *   ARK_API_KEY=xxxx
 *   VOICE_APP_ID=xxxx
 *   VOICE_ACCESS_TOKEN=xxxx
 */
object VolcengineConfig {

    // --- Ark (Chat / traduction) ---
    const val ARK_BASE_URL = "https://ark.cn-beijing.volces.com/api/v3/chat/completions"
    // Remplace par ton API Key réelle (via BuildConfig.ARK_API_KEY en prod)
    var arkApiKey: String = "REMPLACE_MOI"
    // Remplace par l'ID de ton endpoint (ep-xxxxx) ou un nom de modèle Doubao
    var arkModel: String = "doubao-seed-1-6-251015"

    // --- 豆包语音 (ASR + TTS) ---
    const val ASR_URL = "https://openspeech.bytedance.com/api/v1/asr/quick" // à vérifier selon ta souscription
    const val TTS_URL = "https://openspeech.bytedance.com/api/v1/tts"
    var voiceAppId: String = "REMPLACE_MOI"
    var voiceAccessToken: String = "REMPLACE_MOI"

    // --- Langues ---
    enum class TargetLanguage(val arkCode: String, val ttsVoice: String, val label: String) {
        CHINESE(arkCode = "chinois (mandarin)", ttsVoice = "zh_female_qingxin", label = "中文"),
        ARABIC(arkCode = "arabe standard", ttsVoice = "ar_female_default", label = "العربية"),
        ENGLISH(arkCode = "anglais", ttsVoice = "en_female_default", label = "English")
    }

    // Format audio attendu/produit — garde ça synchro avec le firmware ESP32
    const val SAMPLE_RATE_HZ = 16000
    const val CHANNELS = 1
    const val BITS_PER_SAMPLE = 16
}
