package com.annalab.jouetlangues

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class TutorReply(
    val targetReply: String,   // réponse du tuteur dans la langue cible
    val frenchHint: String,    // équivalent français (pour que l'enfant comprenne)
    val correction: String?    // remarque bienveillante si l'enfant a fait une erreur, sinon null
)

data class Lesson(
    val word: String,               // mot/expression dans la langue cible
    val translation: String,        // traduction française
    val exampleSentence: String,    // phrase d'exemple dans la langue cible
    val exampleTranslation: String, // traduction de la phrase
    val quizQuestion: String,       // question posée à l'enfant (en français)
    val quizOptions: List<String>,  // 3 options à choix (dont la bonne)
    val correctAnswerIndex: Int
)

/**
 * Tuteur IA basé sur Ark Chat (Doubao), même authentification Bearer que TranslateApi.
 * Le modèle est contraint à répondre en JSON strict pour un parsing fiable côté appli.
 */
class AiTutorApi {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    /**
     * Un tour de conversation. [history] contient les tours précédents pour garder le contexte
     * (rôle "user" = ce que l'enfant a dit en français, rôle "assistant" = le JSON renvoyé
     * précédemment par le tuteur, stocké tel quel pour que le modèle garde la mémoire du fil).
     */
    suspend fun chatTurn(
        childUtteranceFrench: String,
        target: VolcengineConfig.TargetLanguage,
        history: List<Pair<String, String>> // (role, content)
    ): Result<TutorReply> = withContext(Dispatchers.IO) {
        val systemPrompt = """
            Tu es un tuteur de langue patient et bienveillant pour un enfant qui apprend le
            ${target.arkCode}. L'enfant te parle en français, tu réponds dans un dialogue simple.
            Règles :
            - Réponds toujours par une phrase courte et simple en ${target.arkCode} (target_reply).
            - Donne l'équivalent français de ta réponse (french_hint).
            - Si l'enfant a fait une erreur de grammaire ou de vocabulaire dans sa phrase française
              (ce qui peut arriver s'il essayait de répéter un mot cible), corrige gentiment et
              brièvement dans "correction", sinon mets null.
            - Reste toujours encourageant, jamais moqueur.
            - Réponds UNIQUEMENT avec un JSON de cette forme, sans texte autour :
              {"target_reply": "...", "french_hint": "...", "correction": "..." ou null}
        """.trimIndent()

        callArkJson(systemPrompt, childUtteranceFrench, history).mapCatching { json ->
            TutorReply(
                targetReply = json.getString("target_reply"),
                frenchHint = json.getString("french_hint"),
                correction = if (json.isNull("correction")) null else json.optString("correction", null)
            )
        }
    }

    /** Génère une mini-leçon : un mot/expression + un mini-quiz à choix multiple. */
    suspend fun generateLesson(
        target: VolcengineConfig.TargetLanguage,
        alreadySeenWords: List<String>
    ): Result<Lesson> = withContext(Dispatchers.IO) {
        val systemPrompt = """
            Tu conçois des mini-leçons de ${target.arkCode} pour un enfant francophone débutant.
            Choisis un mot ou une courte expression du quotidien, différent de ceux déjà vus :
            ${alreadySeenWords.joinToString(", ").ifBlank { "(aucun pour l'instant)" }}.
            Construis :
            - le mot/expression en ${target.arkCode} (word)
            - sa traduction française (translation)
            - une phrase d'exemple simple en ${target.arkCode} (example_sentence)
            - sa traduction française (example_translation)
            - une question de quiz en français pour vérifier la compréhension (quiz_question)
            - 3 options de réponse en français, dont une seule correcte (quiz_options, tableau de 3)
            - l'index (0, 1 ou 2) de la bonne réponse (correct_answer_index)
            Réponds UNIQUEMENT avec un JSON de cette forme, sans texte autour :
            {"word": "...", "translation": "...", "example_sentence": "...",
             "example_translation": "...", "quiz_question": "...",
             "quiz_options": ["...", "...", "..."], "correct_answer_index": 0}
        """.trimIndent()

        callArkJson(systemPrompt, "Génère la prochaine leçon.", emptyList()).mapCatching { json ->
            val optionsArray = json.getJSONArray("quiz_options")
            Lesson(
                word = json.getString("word"),
                translation = json.getString("translation"),
                exampleSentence = json.getString("example_sentence"),
                exampleTranslation = json.getString("example_translation"),
                quizQuestion = json.getString("quiz_question"),
                quizOptions = (0 until optionsArray.length()).map { optionsArray.getString(it) },
                correctAnswerIndex = json.getInt("correct_answer_index")
            )
        }
    }

    private suspend fun callArkJson(
        systemPrompt: String,
        userMessage: String,
        history: List<Pair<String, String>>
    ): Result<JSONObject> = withContext(Dispatchers.IO) {
        try {
            val messages = JSONArray().apply {
                put(JSONObject().apply { put("role", "system"); put("content", systemPrompt) })
                history.forEach { (role, content) ->
                    put(JSONObject().apply { put("role", role); put("content", content) })
                }
                put(JSONObject().apply { put("role", "user"); put("content", userMessage) })
            }

            val body = JSONObject().apply {
                put("model", VolcengineConfig.arkModel)
                put("messages", messages)
                put("temperature", 0.4)
                put("max_tokens", 400)
            }

            val request = Request.Builder()
                .url(VolcengineConfig.ARK_BASE_URL)
                .addHeader("Authorization", "Bearer ${VolcengineConfig.arkApiKey}")
                .addHeader("Content-Type", "application/json")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("Ark HTTP ${response.code} : $text"))
                }
                val content = JSONObject(text)
                    .optJSONArray("choices")
                    ?.optJSONObject(0)
                    ?.optJSONObject("message")
                    ?.optString("content")
                    ?.trim()
                    ?: return@withContext Result.failure(Exception("Réponse vide d'Ark : $text"))

                // Le modèle peut parfois entourer le JSON de ```json ... ``` malgré la consigne
                val cleaned = content.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
                Result.success(JSONObject(cleaned))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
