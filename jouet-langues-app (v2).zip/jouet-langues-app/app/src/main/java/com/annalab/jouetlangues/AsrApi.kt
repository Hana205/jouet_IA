package com.annalab.jouetlangues

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Appel de l'API "一句话识别" (reconnaissance vocale courte) de 豆包语音.
 *
 * ⚠️ À vérifier avant usage : le format exact du endpoint et du body peut varier
 * selon la version d'API activée sur ta console (Bearer token vs signature).
 * Ceci suit le schéma standard décrit dans "鉴权方法" (Bearer token, header
 * Authorization: Bearer;<access_token>, appid dans le corps de la requête).
 */
class AsrApi {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    /** [pcmData] = audio brut 16kHz/16bit/mono reçu de l'ESP32. Retourne le texte reconnu (FR). */
    suspend fun recognizeFrench(pcmData: ByteArray): Result<String> = withContext(Dispatchers.IO) {
        try {
            val wav = WavUtils.pcmToWav(pcmData)
            val audioB64 = Base64.encodeToString(wav, Base64.NO_WRAP)

            val body = JSONObject().apply {
                put("app", JSONObject().apply {
                    put("appid", VolcengineConfig.voiceAppId)
                    put("cluster", "volc_auc_common") // cluster ASR standard, à ajuster selon ton offre
                })
                put("user", JSONObject().apply { put("uid", "jouet-langues") })
                put("audio", JSONObject().apply {
                    put("format", "wav")
                    put("rate", VolcengineConfig.SAMPLE_RATE_HZ)
                    put("channel", VolcengineConfig.CHANNELS)
                    put("bits", VolcengineConfig.BITS_PER_SAMPLE)
                    put("data", audioB64)
                })
                put("request", JSONObject().apply {
                    put("reqid", System.currentTimeMillis().toString())
                    put("language", "fr-FR")
                })
            }

            val request = Request.Builder()
                .url(VolcengineConfig.ASR_URL)
                .addHeader("Authorization", "Bearer;${VolcengineConfig.voiceAccessToken}")
                .addHeader("Content-Type", "application/json")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("ASR HTTP ${response.code} : $text"))
                }
                val json = JSONObject(text)
                // La clé exacte du résultat dépend de la version d'API (souvent "result" > liste de segments)
                val recognized = json.optJSONArray("result")
                    ?.optJSONObject(0)
                    ?.optString("text")
                    ?: json.optString("text", "")

                if (recognized.isBlank()) {
                    Result.failure(Exception("Aucun texte reconnu. Réponse brute : $text"))
                } else {
                    Result.success(recognized)
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
