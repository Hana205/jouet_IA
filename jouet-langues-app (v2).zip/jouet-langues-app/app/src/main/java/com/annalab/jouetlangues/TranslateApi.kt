package com.annalab.jouetlangues

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Traduction via l'API Chat d'Ark (modèle Doubao), authentification Bearer token simple.
 * Plus simple à mettre en œuvre que l'API "Traduction de texte" dédiée, qui exige
 * une signature HMAC AK/SK.
 */
class TranslateApi {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    suspend fun translate(
        frenchText: String,
        target: VolcengineConfig.TargetLanguage
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val systemPrompt = "Tu es un traducteur pour enfants. Traduis la phrase donnée du " +
                "français vers le ${target.arkCode}. Réponds UNIQUEMENT avec la traduction, " +
                "sans guillemets, sans explication, sans pinyin ni translittération."

            val body = JSONObject().apply {
                put("model", VolcengineConfig.arkModel)
                put("messages", JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "system")
                        put("content", systemPrompt)
                    })
                    put(JSONObject().apply {
                        put("role", "user")
                        put("content", frenchText)
                    })
                })
                put("temperature", 0.2)
                put("max_tokens", 200)
            }

            val request = Request.Builder()
                .url(VolcengineConfig.ARK_BASE_URL)
                .addHeader("Authorization", "Bearer ${VolcengineConfig.arkApiKey}")
                .addHeader("Content-Type", "application/json")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("Ark HTTP ${response.code} : $text"))
                }
                val json = JSONObject(text)
                val translated = json.optJSONArray("choices")
                    ?.optJSONObject(0)
                    ?.optJSONObject("message")
                    ?.optString("content")
                    ?.trim()

                if (translated.isNullOrBlank()) {
                    Result.failure(Exception("Réponse vide d'Ark. Brut : $text"))
                } else {
                    Result.success(translated)
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
