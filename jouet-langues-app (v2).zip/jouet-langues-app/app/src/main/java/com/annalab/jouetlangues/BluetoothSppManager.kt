package com.annalab.jouetlangues

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import kotlinx.coroutines.*
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

/**
 * Gère la connexion Bluetooth Classic SPP avec l'ESP32.
 *
 * Protocole attendu côté ESP32 (à respecter dans le firmware) :
 *   - Trame audio : [0xAA 0x55] [longueur uint32 little-endian] [données PCM 16bit mono 16kHz]
 *   - Octet seul 0x01 : signal "fin d'enregistrement" (relâchement du bouton)
 */
class BluetoothSppManager(private val onStatusChanged: (String) -> Unit) {

    companion object {
        // UUID standard du profil SPP (Serial Port Profile)
        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val FRAME_HEADER_1: Int = 0xAA
        private const val FRAME_HEADER_2: Int = 0x55
        private const val END_OF_RECORDING: Int = 0x01
    }

    private var socket: BluetoothSocket? = null
    private var inputStream: InputStream? = null
    private var outputStream: OutputStream? = null
    private var listenJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    val isConnected: Boolean
        get() = socket?.isConnected == true

    @SuppressLint("MissingPermission")
    suspend fun connect(device: BluetoothDevice): Boolean = withContext(Dispatchers.IO) {
        try {
            BluetoothAdapter.getDefaultAdapter()?.cancelDiscovery()
            val sock = device.createRfcommSocketToServiceRecord(SPP_UUID)
            sock.connect()
            socket = sock
            inputStream = sock.inputStream
            outputStream = sock.outputStream
            onStatusChanged("Connecté à ${device.name ?: device.address}")
            true
        } catch (e: IOException) {
            onStatusChanged("Échec de connexion : ${e.message}")
            close()
            false
        }
    }

    /**
     * Écoute en continu le flux entrant. Appelle [onAudioReceived] avec les données PCM
     * complètes dès qu'une trame audio est terminée (signalée par END_OF_RECORDING).
     */
    fun startListening(onAudioReceived: (ByteArray) -> Unit) {
        listenJob?.cancel()
        listenJob = scope.launch {
            val stream = inputStream ?: return@launch
            val buffer = ByteArrayOutputStream()
            val readBuf = ByteArray(1024)
            try {
                while (isActive && isConnected) {
                    val n = stream.read(readBuf)
                    if (n <= 0) continue

                    var i = 0
                    while (i < n) {
                        val b = readBuf[i].toInt() and 0xFF
                        if (b == END_OF_RECORDING && buffer.size() > 0) {
                            // Fin d'enregistrement : on livre l'audio accumulé
                            val audio = buffer.toByteArray()
                            buffer.reset()
                            withContext(Dispatchers.Main) { onAudioReceived(audio) }
                        } else {
                            buffer.write(b)
                        }
                        i++
                    }
                }
            } catch (e: IOException) {
                onStatusChanged("Connexion perdue : ${e.message}")
            }
        }
    }

    /**
     * Envoie de l'audio (ex: réponse TTS) à l'ESP32, encadré par l'en-tête de trame.
     * Utile pour la V2 où le jouet restitue le son lui-même plutôt que le téléphone.
     */
    suspend fun sendAudio(pcmData: ByteArray) = withContext(Dispatchers.IO) {
        val out = outputStream ?: return@withContext
        try {
            val header = byteArrayOf(
                FRAME_HEADER_1.toByte(), FRAME_HEADER_2.toByte(),
                (pcmData.size and 0xFF).toByte(),
                ((pcmData.size shr 8) and 0xFF).toByte(),
                ((pcmData.size shr 16) and 0xFF).toByte(),
                ((pcmData.size shr 24) and 0xFF).toByte()
            )
            out.write(header)
            out.write(pcmData)
            out.flush()
        } catch (e: IOException) {
            onStatusChanged("Échec d'envoi audio : ${e.message}")
        }
    }

    fun close() {
        listenJob?.cancel()
        try { inputStream?.close() } catch (_: IOException) {}
        try { outputStream?.close() } catch (_: IOException) {}
        try { socket?.close() } catch (_: IOException) {}
        socket = null
    }
}
