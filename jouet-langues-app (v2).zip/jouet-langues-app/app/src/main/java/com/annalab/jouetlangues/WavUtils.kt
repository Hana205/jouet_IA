package com.annalab.jouetlangues

import java.io.ByteArrayOutputStream

/** Ajoute un en-tête WAV (44 octets) devant du PCM 16 bits brut. */
object WavUtils {

    fun pcmToWav(
        pcmData: ByteArray,
        sampleRate: Int = VolcengineConfig.SAMPLE_RATE_HZ,
        channels: Int = VolcengineConfig.CHANNELS,
        bitsPerSample: Int = VolcengineConfig.BITS_PER_SAMPLE
    ): ByteArray {
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val blockAlign = channels * bitsPerSample / 8
        val dataSize = pcmData.size
        val chunkSize = 36 + dataSize

        val out = ByteArrayOutputStream(44 + dataSize)
        fun writeInt(v: Int) {
            out.write(v and 0xFF); out.write((v shr 8) and 0xFF)
            out.write((v shr 16) and 0xFF); out.write((v shr 24) and 0xFF)
        }
        fun writeShort(v: Int) {
            out.write(v and 0xFF); out.write((v shr 8) and 0xFF)
        }

        out.write("RIFF".toByteArray())
        writeInt(chunkSize)
        out.write("WAVE".toByteArray())
        out.write("fmt ".toByteArray())
        writeInt(16)                 // taille du sous-bloc fmt
        writeShort(1)                // format PCM
        writeShort(channels)
        writeInt(sampleRate)
        writeInt(byteRate)
        writeShort(blockAlign)
        writeShort(bitsPerSample)
        out.write("data".toByteArray())
        writeInt(dataSize)
        out.write(pcmData)

        return out.toByteArray()
    }
}
