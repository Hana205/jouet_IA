package com.annalab.jouetlangues

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

sealed class TutorState {
    object Idle : TutorState()
    object Listening : TutorState()
    object Thinking : TutorState()
    object Synthesizing : TutorState()
    data class ConversationTurn(val childText: String, val reply: TutorReply, val audio: ByteArray) : TutorState()
    data class LessonReady(val lesson: Lesson, val audio: ByteArray) : TutorState()
    data class QuizResult(val correct: Boolean, val correctAnswer: String) : TutorState()
    data class Error(val step: String, val message: String) : TutorState()
}

/**
 * Gère les deux sous-modes du tuteur IA :
 *  - CONVERSATION : l'enfant parle en français (audio ESP32) -> ASR -> AiTutorApi.chatTurn -> TTS
 *  - LESSON : déclenché par un bouton (pas de micro) -> AiTutorApi.generateLesson -> TTS du mot
 *
 * L'historique de conversation et les mots déjà vus sont gardés en mémoire pour la session
 * (perdus si l'appli redémarre — un stockage local pourra être ajouté plus tard si besoin).
 */
class TutorOrchestrator(
    private val asrApi: AsrApi = AsrApi(),
    private val tutorApi: AiTutorApi = AiTutorApi(),
    private val ttsApi: TtsApi = TtsApi()
) {
    private val _state = MutableStateFlow<TutorState>(TutorState.Idle)
    val state: StateFlow<TutorState> = _state

    private val conversationHistory = mutableListOf<Pair<String, String>>()
    private val seenLessonWords = mutableListOf<String>()
    private var currentLesson: Lesson? = null

    /** Mode conversation : appelé quand l'ESP32 a envoyé de l'audio (l'enfant vient de parler). */
    suspend fun handleChildSpeech(pcmAudio: ByteArray, target: VolcengineConfig.TargetLanguage) {
        _state.value = TutorState.Thinking

        val asrResult = asrApi.recognizeFrench(pcmAudio)
        val childText = asrResult.getOrElse {
            _state.value = TutorState.Error("ASR", it.message ?: "erreur inconnue")
            return
        }

        val replyResult = tutorApi.chatTurn(childText, target, conversationHistory)
        val reply = replyResult.getOrElse {
            _state.value = TutorState.Error("Tuteur", it.message ?: "erreur inconnue")
            return
        }

        // On garde le fil : le tour de l'enfant, puis la réponse du tuteur (résumée en JSON simple)
        conversationHistory.add("user" to childText)
        conversationHistory.add("assistant" to reply.targetReply)
        // On limite l'historique pour ne pas faire gonfler le coût des appels
        while (conversationHistory.size > 12) conversationHistory.removeAt(0)

        _state.value = TutorState.Synthesizing
        val ttsResult = ttsApi.synthesize(reply.targetReply, target)
        val audio = ttsResult.getOrElse {
            _state.value = TutorState.Error("TTS", it.message ?: "erreur inconnue")
            return
        }

        _state.value = TutorState.ConversationTurn(childText, reply, audio)
    }

    /** Mode leçon : déclenché par un bouton "Leçon suivante" dans l'UI. */
    suspend fun requestNextLesson(target: VolcengineConfig.TargetLanguage) {
        _state.value = TutorState.Thinking

        val lessonResult = tutorApi.generateLesson(target, seenLessonWords)
        val lesson = lessonResult.getOrElse {
            _state.value = TutorState.Error("Leçon", it.message ?: "erreur inconnue")
            return
        }
        currentLesson = lesson
        seenLessonWords.add(lesson.word)

        _state.value = TutorState.Synthesizing
        // On prononce le mot suivi de la phrase d'exemple
        val ttsResult = ttsApi.synthesize("${lesson.word}. ${lesson.exampleSentence}", target)
        val audio = ttsResult.getOrElse {
            _state.value = TutorState.Error("TTS", it.message ?: "erreur inconnue")
            return
        }

        _state.value = TutorState.LessonReady(lesson, audio)
    }

    /** Appelé quand l'enfant tape sur une des options du quiz affichées à l'écran. */
    fun submitQuizAnswer(selectedIndex: Int) {
        val lesson = currentLesson ?: return
        val correct = selectedIndex == lesson.correctAnswerIndex
        _state.value = TutorState.QuizResult(correct, lesson.quizOptions[lesson.correctAnswerIndex])
    }

    fun resetConversation() {
        conversationHistory.clear()
        _state.value = TutorState.Idle
    }
}
