# Jouet de langues — Appli Android (orchestration ASR → Traduction → TTS)

## Architecture retenue

```
ESP32 (micro I2S, bouton)
   │  Bluetooth Classic SPP (audio PCM brut)
   ▼
Appli Android
   1. Reçoit le flux audio (SPP)
   2. ASR "一句话识别" (Doubao/Volcengine)   → texte français
   3. Traduction via Ark Chat (Doubao)       → texte cible
   4. TTS Volcengine                          → audio cible
   5. Joue l'audio (haut-parleur du téléphone en MVP,
      ou renvoi à l'ESP32 via SPP en V2)
```

**Choix important** : la traduction se fait via l'API **Chat (Ark)**, pas via l'API
"Traduction de texte" dédiée. Cette dernière (`translate.volcengineapi.com`) exige une
signature HMAC AK/SK bien plus complexe à implémenter correctement. L'API Ark utilise
un simple Bearer token (`ARK_API_KEY`), tout comme l'ASR et le TTS. Résultat : une seule
méthode d'authentification à gérer dans toute l'appli.

## Comptes / clés nécessaires

Sur https://console.volcengine.com :

1. **火山方舟 (Ark)** → API Key Management → créer une clé → `ARK_API_KEY`
   Créer aussi un point d'accès (Endpoint) sur un modèle Doubao (ex: `doubao-seed-1-6-...`)
   → tu obtiens un `ep-xxxxx` à utiliser comme `model`.
2. **豆包语音 (Voice Tech)** → activer "一句话识别" (ASR) et "语音合成" (TTS)
   → tu obtiens un `appid` et un `access_token` (authentification Bearer token,
   voir doc "鉴权方法").

Stocke ces identifiants dans `local.properties` (jamais commit dans Git) et
injecte-les via `BuildConfig`, voir `VolcengineConfig.kt`.

## Fichiers fournis

| Fichier | Rôle |
|---|---|
| `VolcengineConfig.kt` | Constantes, endpoints, mapping langue cible |
| `AsrApi.kt` | Appel REST "一句话识别" — audio → texte FR |
| `TranslateApi.kt` | Appel Ark Chat — texte FR → texte cible (mode Traduction) |
| `TtsApi.kt` | Appel REST TTS — texte cible → audio |
| `BluetoothSppManager.kt` | Connexion SPP à l'ESP32, envoi/réception audio |
| `TranslationOrchestrator.kt` | Enchaîne les 4 étapes du mode Traduction |
| `LearningMode.kt` | Enum des 3 modes (Traduction / Conversation / Leçon) |
| `AiTutorApi.kt` | Appels Ark Chat pour le tuteur IA (conversation + génération de leçons), sortie JSON structurée |
| `TutorOrchestrator.kt` | Enchaîne ASR → tuteur IA → TTS (mode Conversation), et génération de leçon → TTS (mode Leçon) |
| `MainActivity.kt` | UI avec bascule entre les 3 modes, affichage du quiz |

## Les 3 modes de l'appli

### 1. Traduction (mode d'origine)
L'enfant parle en français, le jouet restitue la traduction dans la langue cible.
Pas de mémoire d'un tour à l'autre.

### 2. Conversation avec le tuteur IA
L'enfant parle en français au jouet. Le tuteur (Ark Chat, prompté comme tuteur bienveillant)
répond dans la langue cible avec une phrase simple, donne l'équivalent français, et corrige
gentiment si l'enfant s'est trompé. L'historique des derniers échanges est gardé en mémoire
(en RAM, perdu à la fermeture de l'appli) pour que les réponses restent cohérentes d'un tour
à l'autre.

### 3. Leçon guidée
Un bouton "Leçon suivante" déclenche la génération d'un mot/expression du quotidien avec
traduction, phrase d'exemple, et un mini-quiz à choix multiple (3 options affichées en boutons
à l'écran — pas de reconnaissance vocale pour la réponse, plus fiable pour un enfant). Les mots
déjà vus dans la session sont transmis au modèle pour éviter les répétitions.

**Limite connue** : la génération de leçon utilise le LLM en mode "créatif contraint" (JSON
structuré) — la qualité pédagogique doit être vérifiée manuellement de temps en temps,
un LLM peut occasionnellement produire une traduction imprécise.

## Dépendances Gradle à ajouter

```kotlin
dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    // org.json est déjà inclus dans le SDK Android, pas besoin de dépendance
}
```

## Permissions AndroidManifest.xml

```xml
<uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
<uses-permission android:name="android.permission.BLUETOOTH_SCAN" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.INTERNET" />
```

(`RECORD_AUDIO` n'est utile que si tu ajoutes plus tard un micro de secours côté
téléphone ; le flux principal vient du micro I2S de l'ESP32 via Bluetooth.)

## Protocole audio ESP32 ↔ Téléphone (à respecter côté firmware)

- PCM 16 bits, mono, 16 kHz (format attendu par l'ASR Volcengine)
- Trame : `[0xAA 0x55] [longueur uint32 little-endian] [données PCM]`
- Un octet `0x01` envoyé seul = "fin d'enregistrement" (déclenché au relâchement du bouton)

## Ce qui reste à faire

- Tester et ajuster le VAD (détection de fin de parole) — actuellement c'est le
  relâchement du bouton qui fait office de fin d'enregistrement (le plus simple
  pour un premier jet).
- Gérer les erreurs réseau (retry, timeout) — actuellement basique.
- V2 : renvoyer l'audio TTS à l'ESP32 via SPP au lieu de le jouer sur le téléphone.
